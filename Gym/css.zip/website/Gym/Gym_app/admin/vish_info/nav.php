<ul id="main-menu" class="">
    <li class="active opened active"><a href="index.php"><i class="entypo-gauge"></i><span>Dashboard</span></a></li>
                
	<li><a href="?vis=new_entry"><i class="entypo-user-add"></i><span>New Registration</span></a>                
				
	<li><a href="?vis=payments"><i class="entypo-star"></i><span>Payments</span></a></li>

	<li><a href="?vis=category"><i class="entypo-users"></i><span>Members</span></a>
		<ul>
			<li class="active">
				<a href="?vis=view_mem"><span>View Members</span></a></li>

			<li><a href="?vis=table_view"><span>View / Enter Schedule</span></a></li>
		</ul>
	</li>

	<li><a href="?vis=new_health_status"><i class="entypo-user-add"></i><span>Health Status</span></a>
        <ul>
          <li class="active">
              <a href="?vis=new_health_status"><span>Enter Health Status</span></a></li>

          <li><a href="?vis=view_health"><span>View Health Status</span></a></li>
		</ul> 
    </li>	
    <li><a href="#"><i class="entypo-quote"></i><span>Plan</span></a>
    <ul>
        <li class="active">
            <a href="?vis=new_plan"><span>New Plan</span></a></li>
    
        <li><a href="?vis=change_values"><span>Edit Subsciption Details</span></a></li>
    </ul>
    </li>
	<li><a href="?vis=new_plan"><i class="entypo-box"></i><span>Overview</span></a>

		<ul>
			<li class="active">
				<a href="?vis=over_members_month"><span>Members per Month</span></a>
			</li>

			<li>
				<a href="?vis=over_members_year"><span>Members per Year</span></a>
			</li>

			<li>
				<a href="?vis=revenue_month"><span>Income per Month</span></a>
			</li>			

		</ul>
    </li>
	<li><a href="?vis=new_plan"><i class="entypo-alert"></i><span>Alerts</span></a>
		<ul>
			<li class="active">
				<a href="?vis=unpaid"><span>Unpaid Members</span></a>
			</li>

			<li>
				<a href="?vis=sub_end"><span>Ending Membership</span></a>
			</li>

		</ul>
	</li>
	<li><a href="?vis=more-userprofile"><i class="entypo-folder"></i><span>Profile</span></a></li>
    <li><a href="?vis=new_account"><i class="entypo-users"></i><span>New Account</span></a></li>
	<li><a href="logout.php"><i class="entypo-logout"></i><span>Logout</span></a></li>

</ul>	