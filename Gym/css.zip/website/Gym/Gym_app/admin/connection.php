<?php
$host         = "localhost";
$user         = "root";
$password     = "";
$databasename = "dbgym";

$con = mysqli_connect($host, $user, $password, $databasename);

?>
