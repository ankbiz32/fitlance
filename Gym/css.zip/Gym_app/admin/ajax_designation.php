<?php
include('db_conn.php');
  if(!empty($_GET['name'])) {
    $query2 = "select * from designation WHERE name='".$_GET['name']."'";
    $result2 = mysqli_query($con, $query2);
    if (mysqli_num_rows($result2) == 0){
	   $query = "insert into designation(name) values ('".$_GET['name']."')";
	  $result = mysqli_query($con, $query);
	  $query1 = "select * from designation ORDER BY id desc";
		$result = mysqli_query($con, $query1);
		$num = mysqli_affected_rows($con);
		if ($num != 0) {
		  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			  echo "<option value=" . $row['id'] . ">" . $row['name'] . "</option>";
			  
		  }
		}
	}else
	{
	    $query1 = "select * from designation ORDER BY id desc";
		$result = mysqli_query($con, $query1);
		$num = mysqli_affected_rows($con);
		if ($num != 0) {
		  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			  echo "<option value=" . $row['id'] . ">" . $row['name'] . "</option>";
			  
		  }
		}
	}
}else{
        $query1 = "select * from designation ORDER BY id desc";
		$result = mysqli_query($con, $query1);
		$num = mysqli_affected_rows($con);
		if ($num != 0) {
		  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			  echo "<option value=" . $row['id'] . ">" . $row['name'] . "</option>";
			  
		  }
		}
}
?>