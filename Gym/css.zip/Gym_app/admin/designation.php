﻿<style>
.hed{
padding-left:10px; 
font-weight:bolder; 
color:#960;
}
</style>
	<form action="submit_designation.php" enctype="multipart/form-data" method="POST" role="form" class="form-horizontal form-groups-bordered">
		<div class="row">
		  <h4 class="hed">Designation</h4>
		  <hr/>
			<div class="col-md-6 form-group"><label for="field-1" class="col-sm-4 control-label">Designation :</label>					
				<div class="col-sm-8"><input type="text" name="name" id="name" class="form-control" placeholder="Designation" ></div>
			</div>
			<div class="col-md-6 form-group"><button type="submit" class="btn btn-primary pull-left">Submit</button></div>
		</div>
	</form>
		
		
		

